var atsnow = new ATSnow({
	classname : 'snow',
	count : 100,
	interval : 40,
	maxSize : 10,
	minSize : 1,
	leftMargin : 10,
	rightMargin : 20,
	bottomMargin : 0,
	maxDistance : 10,
	minDistance : 1
});
atsnow.load();
