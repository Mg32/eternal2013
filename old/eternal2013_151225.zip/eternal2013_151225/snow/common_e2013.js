// 12���A1���A2���̂ݐ���~�点��
var ndate = new Date();
switch (ndate.getMonth()+1) {
case 12:
case 1:
case 2:
	var atsnow = new ATSnow({
		classname : 'snow',
		count : 100,
		interval : 40,
		maxSize : 8,
		minSize : 1,
		leftMargin : 10,
		rightMargin : 20,
		bottomMargin : 0,
		maxDistance : 10,
		minDistance : 1
	});
	atsnow.load();
	break;
}
