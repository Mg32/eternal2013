var AUDIO_EXT = (function() {
	var audio = new Audio();
	var ext = "";
	if		(audio.canPlayType("audio/ogg") == 'maybe') {ext = "ogg";}
	else if	(audio.canPlayType("audio/mp3") == 'maybe') {ext = "mp3";}
	return ext;
})();

var play_gong = function() {
	var audio = new Audio("gong." + AUDIO_EXT);
	audio.play();
};

// �y�[�W�����[�h���ꂽ
onload = function() {
	disptime(); setInterval(disptime, 1000);
	var nd = new Date();
	var m = nd.getMonth() + 1;
	var d = nd.getDate();
	if (m == 12) {
		if (d >= 30) {
			// 12/30, 12/31�͑�A���d�l
			document.getElementById("imgL").src = "yun_5771.jpg";
			document.getElementById("imgR").src = "yun_5771.jpg";
			document.getElementById("imgL").onclick = play_gong;
			document.getElementById("imgR").onclick = play_gong;
			document.getElementById("imgL").style.cursor = "hand";
			document.getElementById("imgR").style.cursor = "hand";
			document.getElementById("imgtext").innerHTML
				+= "<a href=\"http://www.yunphoto.net\">Photo by (C)Tomo.Yun</a>";
		} else {
			// 12���̓N���X�}�X�d�l
			var rnd = Math.round(Math.random());
			document.getElementById("imgL").src = "christmas"+rnd+".png";
			document.getElementById("imgR").src = "christmas"+rnd+".png";
		}
	}
	if (m == 7 || m == 8) {
		// 7�`8���͉Ďd�l
		var rnd = Math.round(Math.random()*4);
		document.getElementById("imgL").src = "natsu"+rnd+".png";
		document.getElementById("imgR").src = "natsu"+rnd+".png";
	}
};

// �\���̍X�V
function disptime() {
	var nd = new Date();
	var sd = new Date(2013, 12-1, 1);
	var lapse = 1+Math.floor((nd.getTime()-sd.getTime())/1000/60/60/24);
	
	var ymd = "2013/12/"+lapse;
	var hms = sprintf("%02d:%02d:%02d",nd.getHours(),nd.getMinutes(),nd.getSeconds());
	
	if (document.getElementById("dt").innerHTML != ymd) {
		// ���t���ς����
		document.getElementById("dt").innerHTML = ymd;
		document.getElementById("twbtn").innerHTML
			= "<a href=\"https://twitter.com/share\" class=\"twitter-share-button\"{count} " +
			  "data-url=\"https://dl.dropboxusercontent.com/u/69466065/eternal2013/index.html\" " +
			  "data-text=\"�G�^�[�i��2013�N\n�{���� 2013�N12��" + lapse + "�� �ł��B\"data-lang=\"ja\">�c�C�[�g</a>";
		twttr.widgets.load();
	}
	
	document.getElementById("tm").innerHTML = hms;
}
